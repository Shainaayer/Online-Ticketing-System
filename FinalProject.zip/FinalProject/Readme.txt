(TOOLS USED)

1) For ER Diagram:_
  - We created ER diagram by using the Lucid chart along with the all team members.


2) For creating the TABLES and INSERTING the data
  - We used Terminal SQLite version 3.36. 

3) For running the queries and taking the screenshot of the outputs
  - Used JetBrains DataGrip 